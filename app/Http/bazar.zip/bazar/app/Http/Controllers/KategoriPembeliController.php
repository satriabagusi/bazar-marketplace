<?php

namespace App\Http\Controllers;

use App\KategoriPembeli;
use Illuminate\Http\Request;

class KategoriPembeliController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\KategoriPembeli  $kategoriPembeli
     * @return \Illuminate\Http\Response
     */
    public function show(KategoriPembeli $kategoriPembeli)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\KategoriPembeli  $kategoriPembeli
     * @return \Illuminate\Http\Response
     */
    public function edit(KategoriPembeli $kategoriPembeli)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\KategoriPembeli  $kategoriPembeli
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, KategoriPembeli $kategoriPembeli)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\KategoriPembeli  $kategoriPembeli
     * @return \Illuminate\Http\Response
     */
    public function destroy(KategoriPembeli $kategoriPembeli)
    {
        //
    }
}

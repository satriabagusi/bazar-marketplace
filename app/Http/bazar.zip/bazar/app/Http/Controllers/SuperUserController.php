<?php

namespace App\Http\Controllers;

use App\SuperUser;
use App\Transaksi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class SuperUserController extends Controller
{
    protected $redirectTo = '/dashboard/superuser';
    public function __construct()
    {
        $this->middleware('superuser');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $transaksi_count = Transaksi::all()->count();
        return view('superuser.dashboard.index', compact('transaksi_count'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('superuser.register', compact('kategoriMerchant', 'jenisMerchant'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        // return $request->all();
        $request->validate([
            'nama' => 'required|string',
            'no_hp_superuser' => 'required',
            'username' => 'required|max:20|unique:merchant',
            'email' => 'required|unique:merchant|email',
            'password' => 'min:4|confirmed|required',
        ]);

            SuperUser::create([
                'nama' => $request->nama,
                'username' => $request->username,
                'email' => $request->email,
                'password' => Hash::make($request['password']),
                'no_hp_superuser' => $request->no_hp_superuser,
            ]);

            Auth::guard('merchant')->logout();
            return redirect('/')->with('status', '0');
    }

    public function __login(Request $request){

        $request->validate([
            'username' => 'required',
            'password' => 'required',
        ]);

        $data = $request->only('username', 'password');

        if (Auth::guard('superuser')->attempt($data)) {
            Auth::guard('merchant')->logout();
            Auth::guard('pembeli')->logout();
            return redirect('/superuser/dashboard');
        }
        return redirect()->back()->with('error', 'Username/Password Salah');

    }

    public function login(){
        if(Auth::guard('superuser')->check()){
            return redirect('/superuser/dashboard');
        }else{
            return view('superuser.login');
        }
    }

    public function dashboard(){
        if(Auth::guard('superuser')->check()){
            return view('superuser.dashboard.index');
        }else{
            return redirect('/superuser/login');
        }
    }

    public function logout(){
        Auth::guard('superuser')->logout();
        return redirect('/');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\SuperUser  $superUser
     * @return \Illuminate\Http\Response
     */
    public function show(SuperUser $superUser)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\SuperUser  $superUser
     * @return \Illuminate\Http\Response
     */
    public function edit(SuperUser $superUser)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\SuperUser  $superUser
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SuperUser $superUser)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\SuperUser  $superUser
     * @return \Illuminate\Http\Response
     */
    public function destroy(SuperUser $superUser)
    {
        //
    }
}

<?php

namespace App\Http\Controllers;

use App\FotoProduk;
use Illuminate\Http\Request;

class FotoProdukController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\FotoProduk  $fotoProduk
     * @return \Illuminate\Http\Response
     */
    public function show(FotoProduk $fotoProduk)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\FotoProduk  $fotoProduk
     * @return \Illuminate\Http\Response
     */
    public function edit(FotoProduk $fotoProduk)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\FotoProduk  $fotoProduk
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, FotoProduk $fotoProduk)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\FotoProduk  $fotoProduk
     * @return \Illuminate\Http\Response
     */
    public function destroy(FotoProduk $fotoProduk)
    {
        //
    }
}

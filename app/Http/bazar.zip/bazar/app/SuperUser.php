<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\SuperUser as Authenticatable;

class SuperUser extends Authenticatable
{
    protected $table = 'superuser';
    
}

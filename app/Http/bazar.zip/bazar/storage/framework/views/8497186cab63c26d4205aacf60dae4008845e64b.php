<?php $__env->startSection('title', 'Bazar Bulan K3 2021'); ?>
<?php $__env->startSection('content'); ?>
    

<!-- Page Content -->
<div class="container">
    
    <div class="row my-5">
        
        <div class="col-lg-3">
            
            <h3 class="my-4">Kategori produk</h3>
            <div class="list-group">
                <?php $__currentLoopData = $jenisMerchant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/produk/filter/kategori/id=<?php echo e($item->id); ?>" class="list-group-item text-decoration-none" ><?php echo e($item->nama_jenis_merchant); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
        </div>
        <!-- /.col-lg-3 -->
        
        <div class="col-lg-9">
            
            <div id="carouselExampleIndicators" class="carousel slide my-4" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner" role="listbox">
                    <div class="carousel-item active">
                        <img class="d-block img-fluid" src="<?php echo e(asset('/img/banner1.jpg')); ?>" alt="First slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block img-fluid" src="<?php echo e(asset('/img/banner2.jpg')); ?>" alt="Second slide">
        </div>
        <div class="carousel-item">
            <img class="d-block img-fluid" src="<?php echo e(asset('/img/banner3.jpg')); ?>" alt="Third slide">
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
        </a>
    </div>
    
    
    <?php if(count($produk) == 0): ?>
    <div class="row justify-content-center my-5">
        <div class="col-4">
            <img class="img-fluid" width="950px" src="/img/product-not-found.jpg" alt="">
            <p class="text-center text-secondary">Belum ada produk terdaftar</p>
            <p class="text-center">Mari menjadi bagian Bazar bulan K3 sebagai merchant !</p>
            <p class="text-center font-weight-bold">Klik <a class="text-decoration-none" href="/merchant/daftar">Disini </a>untuk mendaftar</p>
            </div>
        </div>
        <?php else: ?>
        <div class="row">
            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100 shadow-sm">
                    <?php $__currentLoopData = $item->foto_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img class="card-img-top" src="<?php echo e(url('/gambar-produk/'.$foto->url_foto)); ?>" alt=""  style="width: 700; height: 400;"></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="card-body">
                        <h4 class="card-title">
                            <a href="/produk/detail/<?php echo e($item->id); ?>"><?php echo e($item->nama_produk); ?></a>
                        </h4>
                        <h5>Rp. <span ><?php echo e(number_format($item->harga, 0, ".", ".")); ?></span></h5>
                        <p class="card-text"><?php echo e($item->deskripsi); ?></p>
                        <a class="stretched-link" href="/produk/detail/<?php echo e($item->id); ?>"></a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
        

        <?php if(count($produk) !== 0): ?>
        <div class="mt-3 row text-center justify-content-center">
            <div class="col-10">
                <p class=" text-muted">
                    Jumlah Produk yang ditampilkan <?php echo e($produk->total()); ?> dari <?php echo e($produk->perPage()); ?> per halaman
                </p>
                
                
                <?php echo e($produk->links()); ?>

            </div>
        </div>
        <?php endif; ?>
        
        
        
        <!-- /.row -->
        
    </div>
    <!-- /.col-lg-9 -->
    
</div>
<!-- /.row -->

</div>
<!-- /.container -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bazar\resources\views/index.blade.php ENDPATH**/ ?>